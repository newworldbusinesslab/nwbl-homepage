# New World Business Lab Homepage

This is the animated homepage with globe + flask sequence.
Built for Vercel deployment.
